package com.pointreader.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.pointreader.app.MainActivity
import com.pointreader.app.R
import com.pointreader.app.model.PlaybackStatus
import com.pointreader.app.model.PointItem
import com.pointreader.app.model.SpeechVoiceInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

class PointReaderService : Service(), TextToSpeech.OnInitListener {

    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var wakeLock: PowerManager.WakeLock? = null

    private var points: List<PointItem> = emptyList()
    private var currentIndex: Int = 0
    private var speechSpeed: Float = 1.0f
    private var speechPitch: Float = 1.0f
    private var selectedVoiceName: String? = null

    private val _playbackStatus = MutableStateFlow(PlaybackStatus.IDLE)
    val playbackStatus: StateFlow<PlaybackStatus> = _playbackStatus.asStateFlow()

    private val _currentPointIndex = MutableStateFlow(0)
    val currentPointIndex: StateFlow<Int> = _currentPointIndex.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<SpeechVoiceInfo>>(emptyList())
    val availableVoices: StateFlow<List<SpeechVoiceInfo>> = _availableVoices.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var lastTapTimestamp = 0L
    private val TAP_DEBOUNCE_MS = 250L

    companion object {
        const val CHANNEL_ID = "point_reader_playback_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_PLAY = "com.pointreader.ACTION_PLAY"
        const val ACTION_PAUSE = "com.pointreader.ACTION_PAUSE"
        const val ACTION_NEXT = "com.pointreader.ACTION_NEXT"
        const val ACTION_STOP = "com.pointreader.ACTION_STOP"
        const val ACTION_RESTART = "com.pointreader.ACTION_RESTART"
    }

    inner class LocalBinder : Binder() {
        fun getService(): PointReaderService = this@PointReaderService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
        tts = TextToSpeech(applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.getDefault())
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
            tts?.setSpeechRate(speechSpeed)
            tts?.setPitch(speechPitch)

            setupUtteranceListener()
            isTtsInitialized = true
            loadAvailableVoices()

            if (_playbackStatus.value == PlaybackStatus.PLAYING) {
                speakCurrentPoint()
            }
        } else {
            _errorMessage.value = "Failed to initialize Android TextToSpeech engine."
            _playbackStatus.value = PlaybackStatus.ERROR
        }
    }

    private var repeatUntilSkipped: Boolean = false

    fun setRepeatUntilSkipped(enabled: Boolean) {
        repeatUntilSkipped = enabled
    }

    private fun setupUtteranceListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                serviceScope.launch {
                    _playbackStatus.value = PlaybackStatus.PLAYING
                    updateNotification()
                }
            }

            override fun onDone(utteranceId: String?) {
                serviceScope.launch {
                    if (utteranceId?.startsWith("point_") == true) {
                        if (repeatUntilSkipped) {
                            // User requested: keep repeating same point until clicked/tapped to skip!
                            kotlinx.coroutines.delay(700)
                            if (_playbackStatus.value == PlaybackStatus.PLAYING) {
                                speakCurrentPoint()
                            }
                        } else {
                            advanceToNextPointInternal(userTriggered = false)
                        }
                    }
                }
            }

            override fun onError(utteranceId: String?) {
                serviceScope.launch {
                    _errorMessage.value = "Speech error on point ${currentIndex + 1}"
                    advanceToNextPointInternal(userTriggered = false)
                }
            }
        })
    }

    private fun loadAvailableVoices() {
        try {
            val voices = tts?.voices
            if (!voices.isNullOrEmpty()) {
                val voiceList = voices
                    .map { voice ->
                        val isNatural = voice.name.contains("neural", ignoreCase = true) ||
                                        voice.name.contains("natural", ignoreCase = true) ||
                                        voice.name.contains("wavenet", ignoreCase = true) ||
                                        voice.name.contains("-x-", ignoreCase = true) ||
                                        voice.quality >= 400

                        SpeechVoiceInfo(
                            name = voice.name,
                            localeDisplay = "${voice.locale.displayLanguage} (${voice.locale.displayCountry})",
                            isNetworkRequired = voice.isNetworkConnectionRequired,
                            isNaturalVoice = isNatural
                        )
                    }
                    .sortedWith(compareByDescending<SpeechVoiceInfo> { it.isNaturalVoice }.thenBy { it.localeDisplay })
                _availableVoices.value = voiceList
            }
        } catch (_: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> resumePlayback()
            ACTION_PAUSE -> pausePlayback()
            ACTION_NEXT -> skipToNextPoint()
            ACTION_RESTART -> restartPlayback()
            ACTION_STOP -> stopPlayback()
        }
        return START_NOT_STICKY
    }

    fun setPoints(newPoints: List<PointItem>, startIndex: Int = 0) {
        points = newPoints
        currentIndex = if (newPoints.isNotEmpty()) startIndex.coerceIn(0, newPoints.size - 1) else 0
        _currentPointIndex.value = currentIndex
    }

    fun startPlayback() {
        if (points.isEmpty()) return
        _playbackStatus.value = PlaybackStatus.PLAYING
        startForeground(NOTIFICATION_ID, buildNotification())
        speakCurrentPoint()
    }

    fun pausePlayback() {
        tts?.stop()
        _playbackStatus.value = PlaybackStatus.PAUSED
        updateNotification()
    }

    fun resumePlayback() {
        if (points.isEmpty()) return
        if (currentIndex >= points.size) {
            currentIndex = 0
            _currentPointIndex.value = 0
        }
        _playbackStatus.value = PlaybackStatus.PLAYING
        startForeground(NOTIFICATION_ID, buildNotification())
        speakCurrentPoint()
    }

    fun restartPlayback() {
        tts?.stop()
        currentIndex = 0
        _currentPointIndex.value = 0
        if (points.isNotEmpty()) {
            _playbackStatus.value = PlaybackStatus.PLAYING
            startForeground(NOTIFICATION_ID, buildNotification())
            speakCurrentPoint()
        }
    }

    fun skipToPreviousPoint() {
        val now = System.currentTimeMillis()
        if (now - lastTapTimestamp < TAP_DEBOUNCE_MS) return
        lastTapTimestamp = now

        tts?.stop()
        if (currentIndex > 0) {
            currentIndex--
            _currentPointIndex.value = currentIndex
            speakCurrentPoint()
        } else {
            speakCurrentPoint()
        }
    }

    // Tap anywhere to skip to next point
    fun skipToNextPoint() {
        val now = System.currentTimeMillis()
        if (now - lastTapTimestamp < TAP_DEBOUNCE_MS) return
        lastTapTimestamp = now

        advanceToNextPointInternal(userTriggered = true)
    }

    private fun advanceToNextPointInternal(userTriggered: Boolean) {
        tts?.stop()
        if (currentIndex + 1 < points.size) {
            currentIndex++
            _currentPointIndex.value = currentIndex
            speakCurrentPoint()
        } else {
            _playbackStatus.value = PlaybackStatus.COMPLETED
            updateNotification()
            stopForeground(STOP_FOREGROUND_DETACH)
        }
    }

    fun jumpToPoint(index: Int) {
        if (index in points.indices) {
            tts?.stop()
            currentIndex = index
            _currentPointIndex.value = currentIndex
            if (_playbackStatus.value == PlaybackStatus.PLAYING) {
                speakCurrentPoint()
            }
        }
    }

    private fun speakCurrentPoint() {
        if (!isTtsInitialized || points.isEmpty() || currentIndex !in points.indices) return

        val point = points[currentIndex]
        val textToSpeak = point.spokenText.ifBlank { point.rawText }

        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "point_$currentIndex")

        tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, params, "point_$currentIndex")
        updateNotification()
    }

    fun setSpeechSpeed(speed: Float) {
        speechSpeed = speed
        tts?.setSpeechRate(speed)
    }

    fun setSpeechPitch(pitch: Float) {
        speechPitch = pitch
        tts?.setPitch(pitch)
    }

    fun setVoiceByName(voiceName: String?) {
        selectedVoiceName = voiceName
        if (voiceName == null) return
        try {
            val matchingVoice = tts?.voices?.find { it.name == voiceName }
            if (matchingVoice != null) {
                tts?.voice = matchingVoice
            }
        } catch (_: Exception) {}
    }

    fun stopPlayback() {
        tts?.stop()
        _playbackStatus.value = PlaybackStatus.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PointReader::AudioWakeLock")
        wakeLock?.setReferenceCounted(false)
        wakeLock?.acquire(24 * 60 * 60 * 1000L)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val isPlaying = _playbackStatus.value == PlaybackStatus.PLAYING
        val playPauseAction = if (isPlaying) {
            NotificationCompat.Action.Builder(
                android.R.drawable.ic_media_pause,
                getString(R.string.action_pause),
                getServicePendingIntent(ACTION_PAUSE, 1)
            ).build()
        } else {
            NotificationCompat.Action.Builder(
                android.R.drawable.ic_media_play,
                getString(R.string.action_play),
                getServicePendingIntent(ACTION_PLAY, 2)
            ).build()
        }

        val nextAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_media_next,
            getString(R.string.action_next),
            getServicePendingIntent(ACTION_NEXT, 3)
        ).build()

        val stopAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_close_clear_cancel,
            getString(R.string.action_stop),
            getServicePendingIntent(ACTION_STOP, 4)
        ).build()

        val pointText = if (currentIndex in points.indices) {
            points[currentIndex].rawText.take(120)
        } else {
            "Notes completed"
        }

        val total = points.size
        val pointTitle = if (total > 0) "Point ${currentIndex + 1} of $total" else "Point Reader"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_name)
            .setContentTitle(pointTitle)
            .setContentText(pointText)
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setShowActionsInCompactView(0, 1)
            )
            .setContentIntent(contentIntent)
            .addAction(playPauseAction)
            .addAction(nextAction)
            .addAction(stopAction)
            .setOngoing(isPlaying)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun updateNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        notificationManager?.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun getServicePendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, PointReaderService::class.java).apply {
            this.action = action
        }
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }
}