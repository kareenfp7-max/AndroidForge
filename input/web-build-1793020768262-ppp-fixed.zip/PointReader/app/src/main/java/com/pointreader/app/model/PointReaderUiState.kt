package com.pointreader.app.model

data class PointReaderUiState(
    val rawNotes: String = "",
    val points: List<PointItem> = emptyList(),
    val currentIndex: Int = 0,
    val speechSpeed: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val selectedVoiceName: String? = null,
    val keepScreenAwake: Boolean = true,
    val isInReadingMode: Boolean = false,
    val playbackStatus: PlaybackStatus = PlaybackStatus.IDLE,
    val availableVoices: List<SpeechVoiceInfo> = emptyList(),
    val errorMessage: String? = null,
    val lastSkippedTimestamp: Long = 0L
) {
    val totalPoints: Int
        get() = points.size

    val currentPoint: PointItem?
        get() = points.getOrNull(currentIndex)

    val progress: Float
        get() = if (totalPoints == 0) 0f
                else ((currentIndex + 1).toFloat() / totalPoints).coerceIn(0f, 1f)
}
