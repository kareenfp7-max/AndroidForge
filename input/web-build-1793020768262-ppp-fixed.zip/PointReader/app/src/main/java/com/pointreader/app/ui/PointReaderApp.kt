package com.pointreader.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pointreader.app.model.PlaybackStatus
import com.pointreader.app.ui.screens.ReadingScreen
import com.pointreader.app.viewmodel.PointReaderViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PointReaderApp(viewModel: PointReaderViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    var showSettings by remember { mutableStateOf(false) }

    MaterialTheme {
        if (uiState.isInReadingMode) {
            ReadingScreen(
                uiState = uiState,
                onScreenTapped = { viewModel.onScreenTappedInReadingMode() },
                onPause = { viewModel.pausePlayback() },
                onResume = { viewModel.resumePlayback() },
                onRestart = { viewModel.restartPlayback() },
                onPrevious = { viewModel.previousPoint() },
                onExitReading = { viewModel.exitReadingMode() },
                onOpenSettings = { showSettings = true }
            )
        } else {
            Scaffold(
                topBar = {
                    TopAppBar(title = { Text("Point Reader") })
                }
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Paste your study notes",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "Each non-empty line is read as a separate point.",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    OutlinedTextField(
                        value = uiState.rawNotes,
                        onValueChange = { viewModel.onNotesChanged(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp),
                        label = { Text("Your notes") },
                        placeholder = {
                            Text("1. First point\n2. Second point\n3. Third point")
                        },
                        minLines = 8
                    )

                    Text("Points: ${uiState.totalPoints}")

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.startReading() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null
                            )
                            Text(" Start Reading")
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.loadSampleNotes(
                                    "First point: Read the question carefully.\n" +
                                    "Second point: Recall the important facts.\n" +
                                    "Third point: Review the answer before moving on."
                                )
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Sample Notes")
                        }
                    }

                    OutlinedButton(
                        onClick = { showSettings = !showSettings },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (showSettings) "Hide Settings" else "Speech Settings")
                    }

                    if (showSettings) {
                        SpeechSettings(
                            speed = uiState.speechSpeed,
                            pitch = uiState.speechPitch,
                            selectedVoiceName = uiState.selectedVoiceName,
                            voices = uiState.availableVoices.map { it.name },
                            keepAwake = uiState.keepScreenAwake,
                            onSpeedChange = { viewModel.setSpeechSpeed(it) },
                            onPitchChange = { viewModel.setSpeechPitch(it) },
                            onVoiceChange = { viewModel.setSelectedVoice(it) },
                            onKeepAwakeChange = {
                                viewModel.toggleKeepScreenAwake(it)
                            }
                        )
                    }

                    uiState.errorMessage?.let { message ->
                        Text(
                            text = message,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    if (uiState.playbackStatus == PlaybackStatus.PAUSED) {
                        OutlinedButton(
                            onClick = { viewModel.resumePlayback() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Resume Previous Session")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        if (showSettings && uiState.isInReadingMode) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Speech Settings") },
                text = {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        SpeechSettings(
                            speed = uiState.speechSpeed,
                            pitch = uiState.speechPitch,
                            selectedVoiceName = uiState.selectedVoiceName,
                            voices = uiState.availableVoices.map { it.name },
                            keepAwake = uiState.keepScreenAwake,
                            onSpeedChange = { viewModel.setSpeechSpeed(it) },
                            onPitchChange = { viewModel.setSpeechPitch(it) },
                            onVoiceChange = { viewModel.setSelectedVoice(it) },
                            onKeepAwakeChange = {
                                viewModel.toggleKeepScreenAwake(it)
                            }
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = { showSettings = false }) {
                        Text("Done")
                    }
                }
            )
        }
    }
}

@Composable
private fun SpeechSettings(
    speed: Float,
    pitch: Float,
    selectedVoiceName: String?,
    voices: List<String>,
    keepAwake: Boolean,
    onSpeedChange: (Float) -> Unit,
    onPitchChange: (Float) -> Unit,
    onVoiceChange: (String?) -> Unit,
    onKeepAwakeChange: (Boolean) -> Unit
) {
    var voiceMenuExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Speech speed: ${"%.1f".format(speed)}x")
            Slider(
                value = speed,
                onValueChange = onSpeedChange,
                valueRange = 0.5f..2.0f
            )

            Text("Speech pitch: ${"%.1f".format(pitch)}")
            Slider(
                value = pitch,
                onValueChange = onPitchChange,
                valueRange = 0.5f..2.0f
            )

            Text("Voice")
            OutlinedButton(
                onClick = { voiceMenuExpanded = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(selectedVoiceName ?: "System default voice")
            }

            DropdownMenu(
                expanded = voiceMenuExpanded,
                onDismissRequest = { voiceMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("System default voice") },
                    onClick = {
                        onVoiceChange(null)
                        voiceMenuExpanded = false
                    }
                )
                voices.distinct().forEach { voice ->
                    DropdownMenuItem(
                        text = { Text(voice) },
                        onClick = {
                            onVoiceChange(voice)
                            voiceMenuExpanded = false
                        }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Keep screen awake")
                Switch(
                    checked = keepAwake,
                    onCheckedChange = onKeepAwakeChange
                )
            }
        }
    }
}
