package com.pointreader.app.model

data class SpeechVoiceInfo(
    val name: String,
    val localeDisplay: String,
    val isNetworkRequired: Boolean,
    val isNaturalVoice: Boolean
)
