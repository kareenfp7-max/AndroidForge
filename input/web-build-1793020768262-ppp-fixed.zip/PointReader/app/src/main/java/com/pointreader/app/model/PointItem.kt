package com.pointreader.app.model

data class PointItem(
    val index: Int,
    val rawText: String,
    val spokenText: String
)
