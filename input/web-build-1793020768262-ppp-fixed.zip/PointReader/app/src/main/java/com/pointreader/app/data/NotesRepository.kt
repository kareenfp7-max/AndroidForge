package com.pointreader.app.data

import android.content.Context

class NotesRepository(context: Context) {

    private val prefs = context.getSharedPreferences(
        "point_reader_preferences",
        Context.MODE_PRIVATE
    )

    fun getSavedNotes(): String =
        prefs.getString("saved_notes", "") ?: ""

    fun saveNotes(notes: String) {
        prefs.edit().putString("saved_notes", notes).apply()
    }

    fun getSpeed(): Float =
        prefs.getFloat("speech_speed", 1.0f)

    fun saveSpeed(speed: Float) {
        prefs.edit().putFloat("speech_speed", speed).apply()
    }

    fun getPitch(): Float =
        prefs.getFloat("speech_pitch", 1.0f)

    fun savePitch(pitch: Float) {
        prefs.edit().putFloat("speech_pitch", pitch).apply()
    }

    fun getVoiceName(): String? =
        prefs.getString("voice_name", null)

    fun saveVoiceName(name: String?) {
        prefs.edit().putString("voice_name", name).apply()
    }

    fun isKeepAwake(): Boolean =
        prefs.getBoolean("keep_screen_awake", true)

    fun saveKeepAwake(enabled: Boolean) {
        prefs.edit().putBoolean("keep_screen_awake", enabled).apply()
    }

    fun getLastIndex(): Int =
        prefs.getInt("last_point_index", 0)

    fun saveLastIndex(index: Int) {
        prefs.edit().putInt("last_point_index", index.coerceAtLeast(0)).apply()
    }
}
