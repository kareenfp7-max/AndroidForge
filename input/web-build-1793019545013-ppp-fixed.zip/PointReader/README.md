# Point Reader - Native Android Application

**Point Reader** is a high-yield, hands-free study & revision reader built with **Kotlin** and **Jetpack Compose**. It allows students and medical candidates to listen to long lists of study notes continuously without having to aim for small on-screen buttons.

## How to Build the APK
1. Open the project in **Android Studio**.
2. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Locate `app-debug.apk` in `app/build/outputs/apk/debug/`.
4. Install on your Android phone via USB, Google Drive, or `adb install -r app-debug.apk`.