package com.pointreader.app.util

object NaturalTextFormatter {

    fun format(text: String): String {
        if (text.isBlank()) return ""

        var spoken = text.trim()
        spoken = spoken.replace(Regex("^(?:\\d+[-.):\\]\\s]+|[•*—–\\-]+\\s*)"), "").trim()
        spoken = spoken.replace(Regex("\\[\\d+\\]"), "")
        spoken = spoken.replace(Regex("\\(([^)]+)\\)"), ", $1,")

        spoken = spoken
            .replace(Regex("\\b~\\s*(\\d+)"), "approximately $1")
            .replace(Regex("(\\d+)%"), "$1 percent")
            .replace(Regex("(\\d+)\\s*mg/dL", RegexOption.IGNORE_CASE), "$1 milligrams per deciliter")
            .replace(Regex("(\\d+)\\s*mmHg", RegexOption.IGNORE_CASE), "$1 millimeters of mercury")
            .replace(Regex("\\bvs\\.?\\b", RegexOption.IGNORE_CASE), "versus")
            .replace(Regex("\\be\\.g\\.,?\\b", RegexOption.IGNORE_CASE), "for example")
            .replace(Regex("\\bi\\.e\\.,?\\b", RegexOption.IGNORE_CASE), "that is")

        spoken = spoken
            .replace(Regex("\\bPTH\\b"), "P T H")
            .replace(Regex("\\bECG\\b"), "E C G")
            .replace(Regex("\\bEKG\\b"), "E K G")
            .replace(Regex("\\bBP\\b"), "blood pressure")
            .replace(Regex("\\bHR\\b"), "heart rate")
            .replace(Regex("\\bIV\\b"), "I V")
            .replace(Regex("\\bMEN1\\b"), "Men one")
            .replace(Regex("\\bMEN2A\\b"), "Men two A")
            .replace(Regex("\\bMEN2B\\b"), "Men two B")
            .replace(Regex("\\bRANKL\\b"), "RANK ligand")
            .replace(Regex("1,25-dihydroxyvitamin\\s*D", RegexOption.IGNORE_CASE), "one, twenty-five dihydroxyvitamin D")

        spoken = spoken
            .replace(Regex("\\s*,\\s*,+"), ", ")
            .replace(Regex("\\s+"), " ")
            .replace(Regex("\\s+,"), ",")
            .trim()

        if (!spoken.endsWith(".") && !spoken.endsWith("!") && !spoken.endsWith("?")) {
            spoken += "."
        }

        return spoken
    }
}