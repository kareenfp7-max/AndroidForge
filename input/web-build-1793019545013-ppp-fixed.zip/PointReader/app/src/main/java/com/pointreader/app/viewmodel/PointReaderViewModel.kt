package com.pointreader.app.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pointreader.app.data.NotesRepository
import com.pointreader.app.model.PointItem
import com.pointreader.app.model.PointReaderUiState
import com.pointreader.app.service.PointReaderService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PointReaderViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = NotesRepository(application)
    private var boundService: PointReaderService? = null
    private var isServiceBound = false

    private val _uiState = MutableStateFlow(PointReaderUiState())
    val uiState: StateFlow<PointReaderUiState> = _uiState.asStateFlow()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as PointReaderService.LocalBinder
            val svc = binder.getService()
            boundService = svc
            isServiceBound = true

            viewModelScope.launch {
                svc.playbackStatus.collect { status ->
                    _uiState.update { it.copy(playbackStatus = status) }
                }
            }
            viewModelScope.launch {
                svc.currentPointIndex.collect { idx ->
                    _uiState.update { it.copy(currentIndex = idx) }
                    repository.saveLastIndex(idx)
                }
            }
            viewModelScope.launch {
                svc.availableVoices.collect { voices ->
                    _uiState.update { it.copy(availableVoices = voices) }
                }
            }
            viewModelScope.launch {
                svc.errorMessage.collect { err ->
                    if (err != null) {
                        _uiState.update { it.copy(errorMessage = err) }
                    }
                }
            }

            val currentPoints = _uiState.value.points
            if (currentPoints.isNotEmpty()) {
                svc.setPoints(currentPoints, _uiState.value.currentIndex)
                svc.setSpeechSpeed(_uiState.value.speechSpeed)
                svc.setSpeechPitch(_uiState.value.speechPitch)
                svc.setVoiceByName(_uiState.value.selectedVoiceName)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            boundService = null
            isServiceBound = false
        }
    }

    init {
        val savedNotes = repository.getSavedNotes()
        val savedSpeed = repository.getSpeed()
        val savedPitch = repository.getPitch()
        val savedVoice = repository.getVoiceName()
        val keepAwake = repository.isKeepAwake()
        val lastIdx = repository.getLastIndex()

        val parsedPoints = parseNotesIntoPoints(savedNotes)
        val validIdx = if (parsedPoints.isNotEmpty()) lastIdx.coerceIn(0, parsedPoints.size - 1) else 0

        _uiState.update {
            it.copy(
                rawNotes = savedNotes,
                points = parsedPoints,
                currentIndex = validIdx,
                speechSpeed = savedSpeed,
                speechPitch = savedPitch,
                selectedVoiceName = savedVoice,
                keepScreenAwake = keepAwake
            )
        }

        bindPlaybackService()
    }

    private fun bindPlaybackService() {
        val intent = Intent(getApplication(), PointReaderService::class.java)
        getApplication<Application>().bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    fun onNotesChanged(newNotes: String) {
        val parsed = parseNotesIntoPoints(newNotes)
        val newIndex = if (parsed.isNotEmpty()) {
            _uiState.value.currentIndex.coerceIn(0, parsed.size - 1)
        } else {
            0
        }

        _uiState.update {
            it.copy(
                rawNotes = newNotes,
                points = parsed,
                currentIndex = newIndex,
                errorMessage = null
            )
        }

        repository.saveNotes(newNotes)
        repository.saveLastIndex(newIndex)
        boundService?.setPoints(parsed, newIndex)
    }

    fun parseNotesIntoPoints(text: String): List<PointItem> {
        if (text.isBlank()) return emptyList()

        val lines = text.split(Regex("\\r?\\n"))
        val points = mutableListOf<PointItem>()

        var pointCounter = 1
        for (rawLine in lines) {
            val trimmed = rawLine.trim()
            if (trimmed.isNotEmpty()) {
                val spoken = trimmed
                    .replace(Regex("^(?:\\d+[-.):\\]\\s]+|[•*\\-–—]+\\s*)"), "")
                    .trim()

                points.add(
                    PointItem(
                        index = pointCounter,
                        rawText = trimmed,
                        spokenText = if (spoken.isNotEmpty()) spoken else trimmed
                    )
                )
                pointCounter++
            }
        }
        return points
    }

    fun startReading() {
        if (_uiState.value.points.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Please enter or paste at least one note point before starting.") }
            return
        }

        _uiState.update {
            it.copy(
                isInReadingMode = true,
                errorMessage = null
            )
        }

        startServiceForeground()
        boundService?.setPoints(_uiState.value.points, _uiState.value.currentIndex)
        boundService?.startPlayback()
    }

    fun exitReadingMode() {
        pausePlayback()
        _uiState.update { it.copy(isInReadingMode = false) }
    }

    fun onScreenTappedInReadingMode() {
        if (!_uiState.value.isInReadingMode) return
        _uiState.update { it.copy(lastSkippedTimestamp = System.currentTimeMillis()) }
        boundService?.skipToNextPoint()
    }

    fun pausePlayback() {
        boundService?.pausePlayback()
    }

    fun resumePlayback() {
        if (_uiState.value.points.isEmpty()) return
        startServiceForeground()
        boundService?.resumePlayback()
    }

    fun restartPlayback() {
        if (_uiState.value.points.isEmpty()) return
        startServiceForeground()
        boundService?.restartPlayback()
    }

    fun previousPoint() {
        boundService?.skipToPreviousPoint()
    }

    fun jumpToPoint(index: Int) {
        boundService?.jumpToPoint(index)
    }

    fun setSpeechSpeed(speed: Float) {
        _uiState.update { it.copy(speechSpeed = speed) }
        repository.saveSpeed(speed)
        boundService?.setSpeechSpeed(speed)
    }

    fun setSpeechPitch(pitch: Float) {
        _uiState.update { it.copy(speechPitch = pitch) }
        repository.savePitch(pitch)
        boundService?.setSpeechPitch(pitch)
    }

    fun setSelectedVoice(voiceName: String?) {
        _uiState.update { it.copy(selectedVoiceName = voiceName) }
        repository.saveVoiceName(voiceName)
        boundService?.setVoiceByName(voiceName)
    }

    fun toggleKeepScreenAwake(enabled: Boolean) {
        _uiState.update { it.copy(keepScreenAwake = enabled) }
        repository.saveKeepAwake(enabled)
    }

    fun loadSampleNotes(presetText: String) {
        onNotesChanged(presetText)
    }

    private fun startServiceForeground() {
        val intent = Intent(getApplication(), PointReaderService::class.java).apply {
            action = PointReaderService.ACTION_PLAY
        }
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                getApplication<Application>().startForegroundService(intent)
            } else {
                getApplication<Application>().startService(intent)
            }
        } catch (_: Exception) {}
    }

    override fun onCleared() {
        if (isServiceBound) {
            try {
                getApplication<Application>().unbindService(serviceConnection)
            } catch (_: Exception) {}
            isServiceBound = false
        }
        super.onCleared()
    }
}